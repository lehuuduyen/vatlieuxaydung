<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\User1\\Providers\\User1ServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\User1\\Providers\\User1ServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);