<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Coin\\Providers\\CoinServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Coin\\Providers\\CoinServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);