
//Chay lenh cai dat
php artisan module:migrate User
php artisan migrate --seed

Link
user/signup


Logs
    Class App\Modules\User\Http\Requests\CreatePostRequest does not exist
    Điều chỉnh "App\Modules" sang "Modules"
    