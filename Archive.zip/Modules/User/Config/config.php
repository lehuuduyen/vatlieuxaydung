<?php

    return [
        'name'             => 'User',
        'default_redirect' => 'sms'
    ];
