<!-- Logo -->
<a href="{{url("public/vendor/adminlte")}}/index2.html" class="logo">
    <!-- mini logo for sidebar mini 50x50 pixels -->
{{--{!! \Setting::get('logoMini') !!}--}}
    {{--<!-- logo for regular state and mobile devices -->--}}
    {{--{!! \Setting::get('logoLg') !!}--}}
</a>
<!-- Header Navbar: style can be found in header.less -->