<div class="pull-right hidden-xs">
    {{--<b>Version</b> {{\Setting::get('version')}}--}}
</div>
{{--{!!\Setting::get('copyright')!!}--}}