<td>
    <a href="http://login.dev-altamedia.com/employment/20" class="btn btn-xs btn-success" title="Chi tiết">
        <i class="fa fa-eye"></i>
    </a> &nbsp;<a href="javascript:setUpdate(20);" class="btn btn-xs btn-primary" title="Chỉnh sửa">
        <i class="fa fa-edit"></i>
    </a> &nbsp;<a href="javascript:setUpdate(20);" class="btn btn-xs btn-danger" title="Xóa">
        <i class="fa fa-times"></i>
    </a> &nbsp;
</td>