@extends('layouts.app')

@section('content')
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<h1>
			CÔNG TRÌNH
			<small>quản lý danh sách công trình</small>
		</h1>
		<ol class="breadcrumb">
			<li>
				<a href="#">
					<i class="fa fa-dashboard"></i>
					Home
				</a>
			</li>
			<li>
				<a href="#">công trình</a>
			</li>
			<li class="active">Data tables</li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-xs-12">
				<a data-toggle="modal" data-target="#modal-AddJob" class="btn btn-app js-open-modal-user">
					<i class="fa fa-edit"></i>
					THÊM CÔNG TRÌNH
				</a>
				<div class="box">
					<div class="box-header">
						<h3 class="box-title">Danh Sach Công Trình</h3>
					</div>
					<!-- /.box-header -->
					<div class="box-body">
						<table id="example1" class="table table-bordered table-striped">
							<thead>
							<tr>
								<th>Mã</th>
								<th>Tên</th>
								<th>Tiên độ</th>
								<th>Đội Trưởng</th>
								<th>Tình trạng</th>
								<th>Hành động</th>
							</tr>
							</thead>
							<tbody>
							@for($i = 1; $i < 40; $i++)
								<tr>
									<td>CT{{$i}}</td>
									<td>Xây nhà số {{rand(111,999)}}/{{rand(1111,9999)}} Nguyễn Trãi</td>
									<td>
										<span class="badge bg-light-blue">{{rand(0,99)}}%</span>
									</td>
									<td>Nguyễn Thế Bảo</td>
									<td>
										<span class="label label-warning">Đang thi công</span>
									</td>
									<td>
										<div class="btn-group">
											<a href="{{url('congtrinh_chitiet')}}" class="btn btn-default">Chi tiết
											</a>
											<a type="button" class="btn btn-default">Xóa</a>
										</div>
									</td>
								</tr>
							@endfor
							</tbody>
						</table>
					</div>
					<!-- /.box-body -->
				</div>
				<!-- /.box -->
			</div>
			<!-- /.col -->
		</div>
		<!-- /.row -->
	</section>
	<!-- /.content -->
@endsection
