@extends('layouts.app')

@section('content')
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<h1>
			CÔNG TRÌNH
			<small>chi tiết công trình</small>
		</h1>
		<ol class="breadcrumb">
			<li>
				<a href="#">
					<i class="fa fa-dashboard"></i>
					Home
				</a>
			</li>
			<li>
				<a href="#">công trình</a>
			</li>
			<li class="active">chi tiết công trình</li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-md-3">
				<!-- Profile Image -->
				<div class="box box-primary">
					<div class="box-body box-profile">
						<h3 class="profile-username text-center">172/102 Nguyễn Trãi</h3>
						<p class="text-muted text-center">Dự Án</p>
						<ul class="list-group list-group-unbordered">
							<li class="list-group-item">
								<b>Tiến độ</b>
								<a class="pull-right">{{rand(0,99)}}%</a>
							</li>
						</ul>
					</div>
					<!-- /.box-body -->
				</div>
				<!-- /.box -->
				<!-- About Me Box -->
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Thông tin dự án</h3>
					</div>
					<!-- /.box-header -->
					<div class="box-body">
						<strong>
							<i class="fa fa-book margin-r-5"></i>
							Mô tả</strong>
						<p class="text-muted">
							Dự án xấy dự án xây dựng nhà ở số 172/102 Nguyễn Trãi, ngôi nhà tương đối lớn với nhiều kết
							cấu phức tạp
						</p>
					</div>
					<!-- /.box-body -->
				</div>
				<!-- /.box -->
			</div>
			<!-- /.col -->
			<div class="col-md-9">
				<div class="nav-tabs-custom">
					<ul class="nav nav-tabs">
						<li class="active">
							<a href="#dutoan1" data-toggle="tab">Dự Toán</a>
						</li>
						<li>
							<a href="#thatdung" data-toggle="tab">Thật dùng</a>
						</li>
						<li>
							<a href="#thongke" data-toggle="tab">Thống kê</a>
						</li>
						<li>
							<a href="#traodoi" data-toggle="tab">Trao đổi</a>
						</li>
						<li>
							<a href="#nhansu" data-toggle="tab">Nhân sự</a>
						</li>
					</ul>
					<div class="tab-content">
						<div class="active tab-pane" id="dutoan1">
							<a data-toggle="modal" data-target="#modal-AddJob" class="btn btn-app js-open-modal-user">
								<i class="fa fa-edit"></i>
								THÊM SẢN PHẨM
							</a>
							<div class="box">
								<div class="box-header">
									<h3 class="box-title">Danh Sách Dự Toán</h3>
								</div>
								<!-- /.box-header -->
								<div class="box-body no-padding">
									<table class="table table-condensed">
										<tbody>
										<tr>
											<th style="width: 10px">Mã</th>
											<th>Tên</th>
											<th>Đơn vị tính</th>
											<th>Đơn giá</th>
											<th>Số lượng</th>
											<th>Tổng tiền</th>
											<th style="width: 40px"></th>
										</tr>
										<tr>
											<td>1.</td>
											<td>Đá 4x6 xanh</td>
											<td>
												Khối
											</td>
											<td>
												1.000.000
											</td>
											<td>
												10
											</td>
											<td>
												10.000.000
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										<tr>
											<td>1.</td>
											<td>Đá 4x6 xanh</td>
											<td>
												Khối
											</td>
											<td>
												1.000.000
											</td>
											<td>
												10
											</td>
											<td>
												10.000.000
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										<tr>
											<td>1.</td>
											<td>Đá 4x6 xanh</td>
											<td>
												Khối
											</td>
											<td>
												1.000.000
											</td>
											<td>
												10
											</td>
											<td>
												10.000.000
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										<tr>
											<td>1.</td>
											<td>Đá 4x6 xanh</td>
											<td>
												Khối
											</td>
											<td>
												1.000.000
											</td>
											<td>
												10
											</td>
											<td>
												10.000.000
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										<tr>
											<td>1.</td>
											<td>Đá 4x6 xanh</td>
											<td>
												Khối
											</td>
											<td>
												1.000.000
											</td>
											<td>
												10
											</td>
											<td>
												10.000.000
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										<tr>
											<td>1.</td>
											<td>Đá 4x6 xanh</td>
											<td>
												Khối
											</td>
											<td>
												1.000.000
											</td>
											<td>
												10
											</td>
											<td>
												10.000.000
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										</tbody>
									</table>
									<hr>
									<div class="row">
										<div class="col-xs-6">
											<p class="lead"><b>&nbsp;&nbsp;Phê duyệt:</b></p>
											<table class="table table-condensed">
												<tbody>
												<tr>
													<th style="width: 10px">#</th>
													<th>Họ & Tên</th>
													<th>Chức vụ</th>
													<th>Hành động</th>
													<th>Thời gian</th>
												</tr>
												<tr>
													<td>1.</td>
													<td>Nguyễn Văn A</td>
													<td>
														Giám Đốc
													</td>
													<td>
														Đã duyệt
													</td>
													<td>
														18:00:00 22/02/2018
													</td>
												</tr>
												</tbody>
											</table>
										</div>
										<!-- /.col -->
										<div class="col-xs-6">
											<p class="lead">Thời gian tạo 22/2/2018</p>
											<div class="table-responsive">
												<table class="table">
													<tbody>
													<tr>
														<th style="width:50%">Tổng tiền:</th>
														<td>200.000.000 vnđ</td>
													</tr>
													</tbody>
												</table>
											</div>
										</div>
										<!-- /.col -->
									</div>
								</div>
								<!-- /.box-body -->
							</div>
						</div>
						<!-- /.tab-pane -->
						<div class="tab-pane" id="thatdung">
							<a data-toggle="modal" data-target="#modal-AddJob" class="btn btn-app js-open-modal-user">
								<i class="fa fa-edit"></i>
								THÊM NHÂN SỰ
							</a>
							<div class="box">
								<div class="box-header">
									<h3 class="box-title">Danh Sách Xuất Kho</h3>
								</div>
								<!-- /.box-header -->
								<div class="box-body no-padding">
									<table class="table table-condensed">
										<tbody>
										<tr>
											<th style="width: 10px">Mã</th>
											<th>Tên</th>
											<th>Đơn vị tính</th>
											<th>Đơn giá</th>
											<th>Số lượng</th>
											<th>Tổng tiền</th>
											<th style="width: 40px"></th>
										</tr>
										<tr>
											<td>1.</td>
											<td>Đá 4x6 xanh</td>
											<td>
												Khối
											</td>
											<td>
												1.000.000
											</td>
											<td>
												10
											</td>
											<td>
												10.000.000
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										<tr>
											<td>1.</td>
											<td>Đá 4x6 xanh</td>
											<td>
												Khối
											</td>
											<td>
												1.000.000
											</td>
											<td>
												10
											</td>
											<td>
												10.000.000
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										<tr>
											<td>1.</td>
											<td>Đá 4x6 xanh</td>
											<td>
												Khối
											</td>
											<td>
												1.000.000
											</td>
											<td>
												10
											</td>
											<td>
												10.000.000
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										<tr>
											<td>1.</td>
											<td>Đá 4x6 xanh</td>
											<td>
												Khối
											</td>
											<td>
												1.000.000
											</td>
											<td>
												10
											</td>
											<td>
												10.000.000
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										<tr>
											<td>1.</td>
											<td>Đá 4x6 xanh</td>
											<td>
												Khối
											</td>
											<td>
												1.000.000
											</td>
											<td>
												10
											</td>
											<td>
												10.000.000
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										<tr>
											<td>1.</td>
											<td>Đá 4x6 xanh</td>
											<td>
												Khối
											</td>
											<td>
												1.000.000
											</td>
											<td>
												10
											</td>
											<td>
												10.000.000
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										</tbody>
									</table>
									<hr>
									<div class="row">
										<div class="col-xs-6">
											<p class="lead"><b>&nbsp;&nbsp;Phê duyệt:</b></p>
											<table class="table table-condensed">
												<tbody>
												<tr>
													<th style="width: 10px">#</th>
													<th>Họ & Tên</th>
													<th>Chức vụ</th>
													<th>Hành động</th>
													<th>Thời gian</th>
												</tr>
												<tr>
													<td>1.</td>
													<td>Nguyễn Văn A</td>
													<td>
														Giám Đốc
													</td>
													<td>
														Đã duyệt
													</td>
													<td>
														18:00:00 22/02/2018
													</td>
												</tr>
												</tbody>
											</table>
										</div>
										<!-- /.col -->
										<div class="col-xs-6">
											<p class="lead">Thời gian tạo 22/2/2018</p>
											<div class="table-responsive">
												<table class="table">
													<tbody>
													<tr>
														<th style="width:50%">Tổng tiền:</th>
														<td>200.000.000 vnđ</td>
													</tr>
													</tbody>
												</table>
											</div>
										</div>
										<!-- /.col -->
									</div>
								</div>
								<!-- /.box-body -->
							</div>
						</div>
						<!-- /.tab-pane -->
						<div class="tab-pane" id="thongke">
							<div id="container-chart" style="width:100%; height:400px;"></div>
						</div>
						<!-- /.tab-pane -->
						<div class="tab-pane" id="traodoi">
							<div class="box box-warning direct-chat direct-chat-warning">
								<div class="box-header with-border">
									<h3 class="box-title">Trao Đổi</h3>
									<div class="box-tools pull-right">
										<span data-toggle="tooltip" title="" class="badge bg-yellow" data-original-title="3 New Messages">3</span>
										<button type="button" class="btn btn-box-tool" data-widget="collapse">
											<i class="fa fa-minus"></i>
										</button>
										<button type="button" class="btn btn-box-tool" data-toggle="tooltip" title="" data-widget="chat-pane-toggle" data-original-title="Contacts">
											<i class="fa fa-comments"></i>
										</button>
										<button type="button" class="btn btn-box-tool" data-widget="remove">
											<i class="fa fa-times"></i>
										</button>
									</div>
								</div>
								<!-- /.box-header -->
								<div class="box-body">
									<!-- Conversations are loaded here -->
									<div class="direct-chat-messages" style="height: 800px;">
										<!-- Message. Default to the left -->
										<div class="direct-chat-msg">
											<div class="direct-chat-info clearfix">
												<span class="direct-chat-name pull-left">Nguyễn Văn Bảo</span>
												<span class="direct-chat-timestamp pull-right">23 Jan 2:00 pm</span>
											</div>
											<!-- /.direct-chat-img -->
											<div class="direct-chat-text">
												Báo cáo tiền độ dự an cho anh nhé
											</div>
											<!-- /.direct-chat-text -->
										</div>
										<!-- /.direct-chat-msg -->
										<!-- Message to the right -->
										<div class="direct-chat-msg right">
											<div class="direct-chat-info clearfix">
												<span class="direct-chat-name pull-right">Bảo Linh</span>
												<span class="direct-chat-timestamp pull-left">23 Jan 2:05 pm</span>
											</div>
											<!-- /.direct-chat-img -->
											<div class="direct-chat-text">
												Hiện tại công trinh đang đặt mức 30% dự kiến anh
											</div>
											<!-- /.direct-chat-text -->
										</div>
										<!-- /.direct-chat-msg -->
										<!-- Message. Default to the left -->
										<div class="direct-chat-msg">
											<div class="direct-chat-info clearfix">
												<span class="direct-chat-name pull-left">Anh Toàn</span>
												<span class="direct-chat-timestamp pull-right">23 Jan 5:37 pm</span>
											</div>
											<!-- /.direct-chat-img -->
											<div class="direct-chat-text">
												Duyệt giúp em phiếu dự toán nhé anh.
											</div>
											<!-- /.direct-chat-text -->
										</div>
										<!-- /.direct-chat-msg -->
										<!-- Message to the right -->
										<div class="direct-chat-msg right">
											<div class="direct-chat-info clearfix">
												<span class="direct-chat-name pull-right">Nguyễn Văn Bảo</span>
												<span class="direct-chat-timestamp pull-left">23 Jan 6:10 pm</span>
											</div>
											<!-- /.direct-chat-img -->
											<div class="direct-chat-text">
												Ok em. Anh đã duyệt nhé. Triển khai tiếp đi em
											</div>
											<!-- /.direct-chat-text -->
										</div>
										<!-- /.direct-chat-msg -->
									</div>
									<!-- /.box-body -->
									<div class="box-footer">
										<form action="#" method="post">
											<div class="input-group">
												<input type="text" name="message" placeholder="Type Message ..." class="form-control">
												<span class="input-group-btn">
                            <button type="button" class="btn btn-warning btn-flat">Send</button>
                          </span>
											</div>
										</form>
									</div>
									<!-- /.box-footer-->
								</div>
							</div>
							<div class="tab-pane" id="thongke">
								<div id="container-chart" style="width:100%; height:400px;"></div>
							</div>
						</div>
						<!-- /.tab-content -->
						<div class="tab-pane" id="nhansu">
							<a data-toggle="modal" data-target="#modal-AddJob" class="btn btn-app js-open-modal-user">
								<i class="fa fa-edit"></i>
								THÊM SẢN PHẨM
							</a>
							<div class="box">
								<div class="box-header">
									<h3 class="box-title">Danh Sách Nhân Sự</h3>
								</div>
								<!-- /.box-header -->
								<div class="box-body no-padding">
									<table class="table table-condensed">
										<tbody>
										<tr>
											<th>Tên</th>
											<th>Chức vụ</th>
											<th>Thời gian thêm vào</th>
											<th style="width: 40px"></th>
										</tr>
										<tr>
											<td>Nguyễn Văn Bảo</td>
											<td>
												Giám Đốc
											</td>
											<td>
												18:00:00 18/12/2018
											</td>
											<td>
												<a class="btn btn-xs btn-danger btn-Delete">
													<i class="fa fa-times"></i>&nbsp;&nbsp;Xóa
												</a>
											</td>
										</tr>
										</tbody>
									</table>
								</div>
								<!-- /.box-body -->
							</div>
						</div>
						<!-- /.tab-content -->
					</div>
					<!-- /.nav-tabs-custom -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
		</div>
	</section>
	<!-- /.content -->

@endsection

@push('scripts')
	<script src="https://code.highcharts.com/highcharts.js"></script>
	<script>
        Highcharts.chart('container-chart', {
            chart      :{
                type:'column'
            },
            title      :{
                text:'Biểu đồ'
            },
            subtitle   :{
                text:'Hệ thống'
            },
            xAxis      :{
                categories:[
                    'Phiếu 1',
                    'Phiếu 2',
                    'Phiếu 3'
                ],
                crosshair :true
            },
            yAxis      :{
                min  :0,
                title:{
                    text:'vnđ'
                }
            },
            tooltip    :{
                headerFormat:'<span style="font-size:10px">{point.key}</span><table>',
                pointFormat :'<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y:.1f} vnd</b></td></tr>',
                footerFormat:'</table>',
                shared      :true,
                useHTML     :true
            },
            plotOptions:{
                column:{
                    pointPadding:0.2,
                    borderWidth :0
                }
            },
            series     :[{
                name:'Dự toán',
                data:[100000000, 180000000, 210000000]
            }, {
                name:'Xuất kho',
                data:[80000000, 140000000, 180000000]
            }, {
                name:'Lợi nhuận',
                data:[20000000, 40000000, 30000000]
            }]
        });
	</script>
@endpush
