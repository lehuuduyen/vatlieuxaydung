<td>
    </a> &nbsp;<a href="javascript:rowDelete('<?php echo e(route('coin.deleteCoinAddress',['id'=>$data->id])); ?>','<?php echo e(csrf_token()); ?>');" class=" btn btn-xs btn-danger
         " title="Xóa">
        <i class="fa fa-times"></i>
    </a> &nbsp;
</td>