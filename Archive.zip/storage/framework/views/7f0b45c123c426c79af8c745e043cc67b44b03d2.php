<?php $__env->startSection('css'); ?>
	<style>
		animation:godown
		1
		s forwards
		;

		@-webkit-keyframes godown {
			0% {
				transform : translateX(-600px);
				opacity   : 0;
			}
			100% {
				transform : translateX(0px);
				opacity   : 1;
			}
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<section class="content-header">
		<h1>
			Vai trò
		</h1>
	</section>
	<section class="content">
		<div class="row">
			<div class="col-md-3">
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Thêm</h3>
					</div>
					<div class="box-body box-profile">
						<div class="user-details">
							<form class="" method="POST" id="frm-role" action="<?php echo e(route('coin.postCoinAddress')); ?>">
								<div class="">
									<input name="" id="role_id" value="" type="hidden">
									<?php echo csrf_field(); ?>

									<div class="form-group">
										<label>Loại</label>
										<select class="form-control" name="type">
											<option value="btc">btc</option>
											<option value="eth">eth</option>
											<option value="usdt">usdt</option>
										</select>
										<div class="form-group">
											<label>Địa chỉ ví</label>
											<input type="text" class="form-control" name="address">
										</div>
									</div>
								</div>
								<div style="text-align: right; margin-top: 10px;" id="btn_role">
									<button class="btn btn-primary new_role" style="display: none;">Làm mới</button>
									<button type="submit" class="btn btn-primary sub-role">Thêm</button>
								</div>
							</form>
						</div>
					</div>
					<!-- /.box-body -->
				</div>
			</div>
			<div class="col-md-9">
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Danh sách ví</h3>
					</div>
					<div class="box-body" style="background: #c1e8ff">
						<div class="col-md-4" id="table-search">
							<div class="box-body">
								<blockquote>
									<p>Loại coin</p>
									<div class="form-group">
										<div class="checkbox">
											<label>
												<input onclick="typeChanged()" name="type[]" type="checkbox" value="btc" checked>
												BTC
											</label>
										</div>
										<div class="checkbox">
											<label>
												<input onclick="typeChanged()" name="type[]" type="checkbox" value="eth" checked>
												ETH
											</label>
										</div>
										<div class="checkbox">
											<label>
												<input onclick="typeChanged()" name="type[]" type="checkbox" value="usdt" checked>
												USDT
											</label>
										</div>
									</div>
								</blockquote>
							</div>
						</div>
						<div class="col-md-6">
							<div class="box-body">
								<blockquote>
									<p>Trạng thái</p>
									<div class="form-group">
										<div class="checkbox">
											<label>
												<input onclick="typeChanged()" name="status[]" type="checkbox" value="0" checked>
												Đã tạo
											</label>
										</div>
										<div class="checkbox">
											<label>
												<input onclick="typeChanged()" name="status[]" type="checkbox" value="1" checked>
												Đã sử dụng
											</label>
										</div>
									</div>
								</blockquote>
							</div>
						</div>
					</div>
					<div class="box-body" id="list_doctor">
						<div class="col-md-12">
							<table id="tableData" class="table table-bordered table-striped" style="text-align: center">
								<thead>
								<tr>
									<th width="" style="text-align: center;" field="id">#</th>
									<th width="" style="text-align: center;" field="user_id_use">Người dùng</th>
									<th width="" style="text-align: center;" field="type">Coin Type</th>
									<th width="" style="text-align: center;" field="address">Ví</th>
									<th width="" style="text-align: center;" field="created_at">Thời gian tạo</th>
									<th width="" style="text-align: center;" field="status_view">Trạng thái</th>
									<th width="" style="text-align: center;" field="action">Hành động</th>
								</tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('stylesheet'); ?>
	<link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
	<script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
	<script>
        var fields = [];
        var datatables = null;
        $('#tableData > thead > tr > th').each(function(){
            var value = $(this).attr('field');
            fields.push({data:value, name:value});
        }).promise().done(function(){
            datatables = $('#tableData').DataTable({
                processing      :true,
                serverSide      :true,
                "aLengthMenu"   :[[25, 50, 75, - 1], [25, 50, 75, "All"]],
                "iDisplayLength":25,
                ajax            :{
                    url :"<?php echo e(route('coin.CoinAddressAnyData')); ?>",
                    data:function(d){
                        // d.typeSearch = typeSearch;
                        d.statusSearch = statusSearch;
                    }
                },
                order           :
                    [[0, 'desc']],
                columns         :fields
            });
        });
        var typeSearch = [];
        var statusSearch = [];

        function typeChanged(){
            typeSearch = [];
            statusSearch = [];
            $("input[name='type[]']:checked").each(function(){
                typeSearch.push($(this).val());
            });
            $("input[name='status[]']:checked").each(function(){
                statusSearch.push($(this).val());
            });
            datatables.ajax.reload();
        }

        function rowDelete(url, token){
            swal({
                title     :"Xác nhận thao tác?",
                text      :"Dữ liệu sẽ bị xóa!",
                icon      :"warning",
                buttons   :true,
                dangerMode:true,
            })
                .then((willDelete) =>{
                    if(willDelete){
                        swal("Xóa thành công!", {
                            icon:"success",
                        });
                        $.ajax({
                            url    :url,
                            type   :'DELETE',
                            data   :{'csrf_token':token},
                            success:function(result){
                                swal(
                                    'Đã xóa!',
                                    'Dữ liệu đã được xóa.',
                                    'success');
                                datatables.ajax.reload();
                            }
                        });
                    }else{
                        swal("Lệnh đã được hủy");
                    }
                });
        }
	</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>