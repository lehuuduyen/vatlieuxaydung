<td>
	<a href="<?php echo e(route('customer.show',['id'=>$data->id])); ?>" class="btn btn-xs btn-success" title="Chi tiết">
		<i class="fa fa-eye"></i>
	</a>
	</a> &nbsp;<a href="javascript:rowDelete('<?php echo e(route('customer.delete',['id'=>$data->id])); ?>','<?php echo e(csrf_token()); ?>');" class=" btn btn-xs btn-danger
         " title="Xóa">
		<i class="fa fa-times"></i>
	</a> &nbsp;
</td>