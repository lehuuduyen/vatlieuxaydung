<?php $__env->startSection('css'); ?>
    <style>
        animation:godown
        1
        s forwards
        ;

        @-webkit-keyframes godown {
            0% {
                transform : translateX(-600px);
                opacity   : 0;
            }
            100% {
                transform : translateX(0px);
                opacity   : 1;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Vai trò
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Thêm</h3>
                    </div>
                    <div class="box-body box-profile">
                        <div class="user-details">
                            <div class="">
                                <input name="" id="role_id" value="" type="hidden">
                                <form class="" method="POST" id="frm-role" action="<?php echo e(url('/user/roles')); ?>">
                                    <?php echo csrf_field(); ?>

                                    <input name="" id="flag" value="0" type="hidden">
                                    <label>Tên:</label>
                                    <input name="txt_role" id="role" class="form-control">
                                    <label>Mô tả:</label>
                                    <textarea rows="4" cols="50" class="form-control" id="description" name="description"></textarea>
                                    <h5>Chọn quyền</h5>
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p>
                                            <input type="checkbox" id="permission_<?php echo e($item['id']); ?>" name="permission[]" value="<?php echo e($item['id']); ?>"> <?php echo e($item['name']); ?>

                                        </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </form>
                            </div>
                            <div style="text-align: right; margin-top: 10px;" id="btn_role">
                                <button class="btn btn-primary new_role" style="display: none;">Làm mới</button>
                                <button class="btn btn-primary sub-role">Bấm Thêm</button>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Danh sách vai trò</h3>
                    </div>
                    <div class="box-body" id="list_doctor">
                        <div class="col-md-12">
                            <table class="table table-bordered" id="doctor-table" style="text-align: center;vertical-align: middle">
                                <thead>
                                <tr>
                                    <th style="text-align: center;vertical-align: middle">#</th>
                                    <th style="text-align: center;vertical-align: middle">Vai trò</th>
                                    <th style="text-align: center;vertical-align: middle">Mô Tả</th>
                                    <th style="text-align: center;vertical-align: middle">Ngày Tạo</th>
                                    <th style="text-align: center;vertical-align: middle">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($stt++); ?></td>
                                        <td><?php echo e($item['name']); ?></td>
                                        <td><?php echo e($item['description']); ?></td>
                                        <td><?php echo e($item['created_at']); ?></td>
                                        <td>
                                            <button class="btn btn-xs btn-success edit" val_id=<?php echo e($item['id']); ?> style="margin-right:5px;">
                                                <i class="fa fa-edit"></i>
                                            </button>
                                            <button class="btn btn-xs btn-danger" onclick="myclick(<?php echo e($item['id']); ?>)">
                                                <i class="fa fa-times"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>


    <script>
        $.ajaxSetup({
            headers:{
                'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
            },
            success:function(response, newValue){
                if(response.status == 'ok'){
                    toastr.success('Cập nhật thành công!');
                }
            }
        });
        $('#list_doctor .alert').delay('3000').slideUp();
        $('.sub-role').on('click', function(event){
            event.preventDefault();
            var flag = $('#flag').val();
            if(flag == 0){
                $('#frm-role').submit();
            }else{
                var id = $('#role_id').val();
                var selected = [];
                var name = $('#role').val();
                var description = $('#description').val();// console.log(description);return false;
                $('#frm-role input:checked').each(function(){
                    selected.push($(this).val());
                });
                $.ajax({
                    url :'<?php echo e(url('/user/roles')); ?>' + '/' + id,
                    type:'PUT',
                    data:{data:selected, id_role:id, name:name, description:description},
                })
                    .done(function(response){
                        location.reload();
                    })
            }
        });
        $('.edit').on('click', function(event){
            event.preventDefault();
            var id = $(this).attr('val_id');
            $('#frm-role input[type=checkbox]').prop('checked', false);
            $('.sub-role').html("Cập nhật");
            $('.new_role').css('display', 'inline');
            $('#flag').val(1);
            $('#role_id').val(id);
            $.ajax({
                url :'<?php echo e(url('/user/getPermissionOne')); ?>' + '/' + id,
                type:'GET',
            })
                .done(function(data){
                    $.each(data, function(index, el){
                        $('#permission_' + el.permission_id).prop('checked', true);
                        $('#role').val(el.name);
                        $('#description').val(el.description);
                    });
                })
        });
        $('.new_role').on('click', function(event){
            event.preventDefault();
            location.reload();
        });

        function myclick(id){
            toastr.error("<br /><br /><a href='<?php echo e(url('user/roles/delete')); ?>" + '/' + id + "\'><button type='button' id='confirmationRevertYes' class='btn clear' style='color: black'>Yes</button></a><button type='button' id='confirmationRevertNo' class='btn' style='margin-left: 10px;color: black;'>No</button>", 'Bạn có chắc chắn xóa mục này?',
                {
                    closeButton :false,
                    allowHtml   :true,
                    onShown     :function(toast){
                        $("#confirmationRevertNo").click(function(){
                            toastr.clear();
                        });
                    },
                    showDuration:"7000",
                });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>