<!-- Logo -->
<a href="<?php echo e(url("public/vendor/adminlte")); ?>/index2.html" class="logo">
    <!-- mini logo for sidebar mini 50x50 pixels -->

    
    
</a>
<!-- Header Navbar: style can be found in header.less -->