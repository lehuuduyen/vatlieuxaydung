<?php switch($data):
	case (0): ?>
	<span class="label label-success">Chưa xác nhận</span>
	<?php break; ?>

	<?php case (1): ?>
	<span class="label label-info">Hoạt động</span>
	<?php break; ?>
	<?php case (2): ?>
	<span class="label label-danger">Khóa</span>
	<?php break; ?>

<?php endswitch; ?>